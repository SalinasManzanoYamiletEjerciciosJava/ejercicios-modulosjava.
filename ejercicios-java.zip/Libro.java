public class Libro {
    private String id;
    private String autor;
    private boolean prestado;

    public Libro(String id, String autor) {
        this.id = id;
        this.autor = autor;
        this.prestado = false;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }

    public boolean isPrestado() { return prestado; }
    public void setPrestado(boolean prestado) { this.prestado = prestado; }

    public void reservar() { this.prestado = true; }

    public boolean aptoParaPrestamo(int antiguedad) { return antiguedad > 5; }
}