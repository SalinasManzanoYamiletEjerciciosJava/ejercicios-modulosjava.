public class Vehiculo {
    private String marca;
    private int anioFabricacion;
    private int velocidadMaxima;

    public Vehiculo(String marca, int anioFabricacion, int velocidadMaxima) {
        this.marca = marca;
        this.anioFabricacion = anioFabricacion;
        this.velocidadMaxima = velocidadMaxima;
    }

    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }

    public int getAnioFabricacion() { return anioFabricacion; }
    public void setAnioFabricacion(int anioFabricacion) { this.anioFabricacion = anioFabricacion; }

    public int getVelocidadMaxima() { return velocidadMaxima; }
    public void setVelocidadMaxima(int velocidadMaxima) { this.velocidadMaxima = velocidadMaxima; }

    public String encender() {
        if (anioFabricacion > 1990) return "El vehículo encendió correctamente.";
        return "El vehículo es muy antiguo para encender.";
    }

    public int antiguedad(int anioActual) { return anioActual - anioFabricacion; }
}