public class Empleado {
    private String clave;
    private double salario;
    private double retencion;

    public Empleado(String clave, double salario, double retencion) {
        this.clave = clave;
        this.salario = salario;
        this.retencion = retencion;
    }

    public String getClave() { return clave; }
    public void setClave(String clave) { this.clave = clave; }

    public double getSalario() { return salario; }
    public void setSalario(double salario) { this.salario = salario; }

    public double getRetencion() { return retencion; }
    public void setRetencion(double retencion) { this.retencion = retencion; }

    public double salarioNeto() {
        return salario - (salario * retencion / 100);
    }

    public void aumentarSalario(double porcentaje) {
        salario += salario * porcentaje / 100;
    }
}