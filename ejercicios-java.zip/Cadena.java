public class Cadena {
    private String texto;
    private String id;
    private int longitudMaxima;

    public Cadena(String texto, String id, int longitudMaxima) {
        this.texto = texto;
        this.id = id;
        this.longitudMaxima = longitudMaxima;
    }

    public String getTexto() { return texto; }
    public void setTexto(String texto) { this.texto = texto; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public int getLongitudMaxima() { return longitudMaxima; }
    public void setLongitudMaxima(int longitudMaxima) { this.longitudMaxima = longitudMaxima; }

    public String agregarPrefijo(String prefijo) { return prefijo + texto; }

    public int contarEspacios() {
        int c = 0;
        for (char x : texto.toCharArray()) if (x == ' ') c++;
        return c;
    }
}